var resetEmail = document.getElementById("reset-email");
var message = document.getElementById("message");
var sendButton = document.getElementById("send-button");
var openLinkButton = document.getElementById("open-link");
var requestStep = document.getElementById("request-step");
var newPasswordStep = document.getElementById("new-password-step");
var forEmail = document.getElementById("for-email");
var newPasswordInput = document.getElementById("new-password");
var newMessage = document.getElementById("new-message");
var saveButton = document.getElementById("save-button");

var resetEmailAddress = "";

function showMessage(box, text, type) {
  box.textContent = text;
  box.className = type;
}

sendButton.addEventListener("click", function () {
  var email = resetEmail.value.trim().toLowerCase();
  if (email.endsWith(STAFF_DOMAIN) === false) {
    showMessage(message, "Enter your staff email, ending " + STAFF_DOMAIN + ".", "error");
    return;
  }
  resetEmailAddress = email;
  showMessage(message, "If " + email + " has an account, we've sent it a link to choose a new password. The link works once and runs out after 30 minutes.", "info");
  openLinkButton.hidden = false;
});

openLinkButton.addEventListener("click", function () {
  requestStep.hidden = true;
  newPasswordStep.hidden = false;
  forEmail.textContent = "For " + resetEmailAddress + ".";
});

saveButton.addEventListener("click", function () {
  var problem = passwordProblem(newPasswordInput.value);
  if (problem !== "") {
    showMessage(newMessage, problem, "error");
    return;
  }
  var accounts = getAccounts();
  for (var i = 0; i < accounts.length; i++) {
    if (accounts[i].email === resetEmailAddress) {
      accounts[i].password = newPasswordInput.value;
    }
  }
  saveAccounts(accounts);
  showMessage(newMessage, "Your password has been changed. You can now log in with it.", "success");
});
