var nameInput = document.getElementById("full-name");
var emailInput = document.getElementById("reg-email");
var passwordInput = document.getElementById("new-password");
var message = document.getElementById("message");
var registerButton = document.getElementById("register-button");

function showMessage(text, type) {
  message.textContent = text;
  message.className = type;
}

registerButton.addEventListener("click", function () {
  var name = nameInput.value.trim();
  var email = emailInput.value.trim().toLowerCase();
  if (name === "") {
    showMessage("Enter your full name.", "error");
    return;
  }
  if (email.endsWith(STAFF_DOMAIN) === false) {
    showMessage("Only Make-It-All staff can register. Use your email ending " + STAFF_DOMAIN + ".", "error");
    return;
  }
  var problem = passwordProblem(passwordInput.value);
  if (problem !== "") {
    showMessage(problem, "error");
    return;
  }
  if (findAccount(email) !== null) {
    showMessage("There's already an account for this email. Each person can only have one, so log in or reset your password instead.", "error");
    return;
  }
  var accounts = getAccounts();
  var newAccount = { name: name, email: email, password: passwordInput.value, role: "employee" };
  accounts.push(newAccount);
  saveAccounts(accounts);
  showMessage("Your account is ready. You can now log in.", "success");
});
