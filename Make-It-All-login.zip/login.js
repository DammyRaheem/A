var emailInput = document.getElementById("email");
var passwordInput = document.getElementById("password");
var message = document.getElementById("message");
var loginButton = document.getElementById("login-button");

function showMessage(text, type) {
  message.textContent = text;
  message.className = type;
}

loginButton.addEventListener("click", function () {
  var email = emailInput.value.trim().toLowerCase();
  if (email.endsWith(STAFF_DOMAIN) === false) {
    showMessage("Use your staff email address, ending " + STAFF_DOMAIN + ".", "error");
    return;
  }
  if (passwordInput.value === "") {
    showMessage("Enter your password.", "error");
    return;
  }
  var account = findAccount(email);
  if (account === null) {
    showMessage("Incorrect email or password.", "error");
    return;
  }
  if (account.password !== passwordInput.value) {
    showMessage("Incorrect email or password.", "error");
    return;
  }
  sessionStorage.setItem("email", account.email);
  window.location.href = "home.html";
});
