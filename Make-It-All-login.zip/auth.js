var STAFF_DOMAIN = "@make-it-all.co.uk";

var ACCOUNTS = [
  { name: "Amira Khan", email: "amira.khan@make-it-all.co.uk", password: "spanner-kettle-orbit", role: "employee" },
  { name: "Tom Reid", email: "tom.reid@make-it-all.co.uk", password: "spanner-kettle-orbit", role: "employee" },
  { name: "Priya Shah", email: "priya.shah@make-it-all.co.uk", password: "spanner-kettle-orbit", role: "team-leader" },
  { name: "David Cole", email: "david.cole@make-it-all.co.uk", password: "spanner-kettle-orbit", role: "manager" }
];

function getAccounts() {
  var saved = sessionStorage.getItem("accounts");
  if (saved === null) {
    return ACCOUNTS;
  }
  return JSON.parse(saved);
}

function saveAccounts(accounts) {
  sessionStorage.setItem("accounts", JSON.stringify(accounts));
}

function findAccount(email) {
  var accounts = getAccounts();
  for (var i = 0; i < accounts.length; i++) {
    if (accounts[i].email === email) {
      return accounts[i];
    }
  }
  return null;
}

function getCurrentUser() {
  var email = sessionStorage.getItem("email");
  return findAccount(email);
}

function requireLogin() {
  var user = getCurrentUser();
  if (user === null) {
    window.location.href = "login.html";
  }
  return user;
}

function logout() {
  sessionStorage.removeItem("email");
  window.location.href = "login.html";
}

var MIN_PASSWORD_LENGTH = 12;
var COMMON_PASSWORDS = [
  "password1234", "password12345", "123456789012", "qwertyuiop12", "iloveyou1234",
  "welcome12345", "letmein12345", "abcdefghijkl", "111111111111", "makeitall123"
];

function passwordProblem(password) {
  if (password.length < MIN_PASSWORD_LENGTH) {
    return "Your password needs at least " + MIN_PASSWORD_LENGTH + " characters. It has " + password.length + ". Three random words, like coffee train fish, are long and easy to remember.";
  }
  var lowerCase = password.toLowerCase();
  for (var i = 0; i < COMMON_PASSWORDS.length; i++) {
    if (lowerCase === COMMON_PASSWORDS[i]) {
      return "That's one of the most common passwords, so it's easy to guess. Try three random words instead.";
    }
  }
  return "";
}
